/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package grafobusqueda;

import java.util.List;

public class GrafoBusqueda {
    public static void main(String[] args) {
       Grafo grafo = new Grafo(9);

        grafo.agregarArista('A', 'B', 10);
        grafo.agregarArista('A', 'C', 15);
        grafo.agregarArista('B', 'D', 12);
        grafo.agregarArista('B', 'F', 15);
        grafo.agregarArista('C', 'E', 10);
        grafo.agregarArista('C', 'G', 8);
        grafo.agregarArista('D', 'E', 5);
        grafo.agregarArista('D', 'H', 7);
        grafo.agregarArista('E', 'F', 7);
        grafo.agregarArista('E', 'I', 8);
        grafo.agregarArista('F', 'I', 6);
        grafo.agregarArista('G', 'H', 12);
        grafo.agregarArista('H', 'I', 10);

        System.out.println("Lista de Adyacencia:");
        grafo.mostrarAristas();
        
        char origen = 'A';
        char destino = 'I';
        System.out.println("El recorrido es: " + grafo.dijkstra(origen, destino));
        System.out.println("El peso es: " + grafo.sumaPesosAristas(grafo.dijkstra(origen, destino)));
        grafo.mostrarMatrizAdyacencia();
    }
}