/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grafobusqueda;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;
/**
 *
 * @author gisse
 */
// Definición de la clase Grafo
public class Grafo {
    private final int cantidadVertices;
    private final List<List<Arista>> listaAdyacencia;

    // Constructor de la clase Grafo
    public Grafo(int cantidadVertices) {
        this.cantidadVertices = cantidadVertices;
        this.listaAdyacencia = new ArrayList<>(cantidadVertices);
        for (int i = 0; i < cantidadVertices; i++) {
            this.listaAdyacencia.add(new ArrayList<>());
        }
    }

    // Método para agregar una arista al grafo
    public void agregarArista(char origen, char destino, int peso) {
        this.listaAdyacencia.get(origen - 'A').add(new Arista(destino - 'A', peso));
    }

    // Algoritmo de Dijkstra para encontrar la ruta más corta desde un nodo de origen a un nodo de destino
    public List<Character> dijkstra(char origen, char destino) {
        // Cola de prioridad para los nodos a visitar
        PriorityQueue<Nodo> colaPrioridad = new PriorityQueue<>(cantidadVertices, Comparator.comparingInt(a -> a.peso));
        int[] distancias = new int[cantidadVertices]; // Distancias mínimas a cada nodo desde el nodo de origen
        int[] previos = new int[cantidadVertices]; // Nodos previos en la ruta más corta
        Arrays.fill(distancias, Integer.MAX_VALUE);
        Arrays.fill(previos, -1);
        colaPrioridad.add(new Nodo(origen - 'A', 0));
        distancias[origen - 'A'] = 0;

        // Tabla para mostrar el cálculo del peso y la ruta
        System.out.println("Vertice\t| Peso Temporal\t| Peso Final\t| Ruta");
        System.out.println("----------------------------------------------");
        while (!colaPrioridad.isEmpty()) {
            Nodo nodoActual = colaPrioridad.poll();
            int u = nodoActual.vertice;
            for (Arista arista : listaAdyacencia.get(u)) {
                int v = arista.destino;
                int peso = arista.peso;
                if (distancias[u] + peso < distancias[v]) {
                    distancias[v] = distancias[u] + peso;
                    previos[v] = u;
                    colaPrioridad.add(new Nodo(v, distancias[v]));
                }
            }

            // Mostrar el cálculo del peso y la ruta en este paso
            System.out.print((char) (u + 'A') + "\t| " + distancias[u] + "\t\t| ");
            if (distancias[u] == Integer.MAX_VALUE) {
                System.out.print("INF\t\t| ");
            } else {
                System.out.print(distancias[u] + "\t\t| ");
            }
            List<Character> ruta = new ArrayList<>();
            for (int i = destino - 'A'; i != -1; i = previos[i]) {
                ruta.add((char) (i + 'A'));
            }
            Collections.reverse(ruta);
            System.out.println(ruta);
        }
        System.out.println("----------------------------------------------");

        // Construir y devolver la ruta final
        List<Character> rutaFinal = new ArrayList<>();
        for (int i = destino - 'A'; i != -1; i = previos[i]) {
            rutaFinal.add((char) (i + 'A'));
        }
        Collections.reverse(rutaFinal);
        return rutaFinal;
    }

    // Método para calcular la suma de los pesos de las aristas en una ruta
    public int sumaPesosAristas(List<Character> ruta) {
        int suma = 0;
        for (int i = 0; i < ruta.size() - 1; i++) {
            char origen = ruta.get(i);
            char destino = ruta.get(i + 1);
            int peso = obtenerPesoArista(origen, destino);
            suma += peso;
        }
        return suma;
    }

    // Método para mostrar la matriz de adyacencia del grafo
    public void mostrarMatrizAdyacencia() {
        System.out.println("Matriz de Adyacencia es ");
        for (int i = 0; i < cantidadVertices; i++) {
            for (int j = 0; j < cantidadVertices; j++) {
                int peso = obtenerPesoArista((char) ('A' + i), (char) ('A' + j));
                System.out.print((peso == Integer.MAX_VALUE ? "0" : peso) + " ");
            }
            System.out.println();
        }
    }

    // Método para obtener el peso de una arista entre dos nodos
    private int obtenerPesoArista(char origen, char destino) {
        for (Arista arista : listaAdyacencia.get(origen - 'A')) {
            if (arista.destino == destino - 'A') {
                return arista.peso;
            }
        }
        return Integer.MAX_VALUE;
    }
    
    // Método para mostrar la lista de adyacencia del grafo
    public void mostrarAristas() {
        System.out.println("Lista de adyacencia:");
        for (int i = 0; i < cantidadVertices; i++) {
            for (Arista arista : listaAdyacencia.get(i)) {
                System.out.println((char) ('A' + i) + " -> " + (char) ('A' + arista.destino) + " Peso: " + arista.peso);
            }
        }
    }

    // Clase interna para representar una arista
    private static class Arista {
        private final int destino;
        private final int peso;

        public Arista(int destino, int peso) {
            this.destino = destino;
            this.peso = peso;
        }

        public int getDestino() {
            return destino;
        }

        public int getPeso() {
            return peso;
        }
    }

    // Clase interna para representar un nodo en el algoritmo de Dijkstra
    private static class Nodo {
        private final int vertice;
        private final int peso;

        public Nodo(int vertice, int peso) {
            this.vertice = vertice;
            this.peso = peso;
        }
    }}