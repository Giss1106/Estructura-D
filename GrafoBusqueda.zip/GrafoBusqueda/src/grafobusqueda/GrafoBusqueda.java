/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package grafobusqueda;
public class GrafoBusqueda {
    public static void main(String[] args) {
        // TODO code application logic here
        Grafo grafo = new Grafo(5); // Por ejemplo, un grafo con 5 vértices

        // Agregar aristas al grafo
        grafo.agregarArista(0, 1, 6);
        grafo.agregarArista(0, 3, 1);
        grafo.agregarArista(1, 2, 5);
        grafo.agregarArista(1, 3, 1);
        grafo.agregarArista(1, 4, 2);
        grafo.agregarArista(2, 1, 5);
        grafo.agregarArista(2, 4, 5);
        grafo.agregarArista(3, 0, 1);
        grafo.agregarArista(3, 1, 2);
        grafo.agregarArista(3, 4, 1);
        grafo.agregarArista(4, 1, 2);
        grafo.agregarArista(4, 2, 5);
        grafo.agregarArista(4, 3, 1);
        
        System.out.println("EL RECORRIDO ES " + grafo.dijkstra(0, 4));
        System.out.println("EL PESO ES " + grafo.sumaPesosAristas(grafo.dijkstra(0, 4)));
        grafo.mostrarMatrizAdyacencia();
        
    }
}
