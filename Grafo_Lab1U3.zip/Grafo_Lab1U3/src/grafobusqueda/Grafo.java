/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grafobusqueda;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;
/**
 *
 * @author gisse
 */
public class Grafo {
    //matriz de adyacencia
    private final int cantidadVertices;//creo una lista
    private final List<List<Arista>> listaAdyacencia;
    //metodo para inicializar variables
    public Grafo(int cantidadVertices) {
        this.cantidadVertices = cantidadVertices;
        this.listaAdyacencia = new ArrayList<>(cantidadVertices);
        for (int i = 0; i < cantidadVertices; i++) {
            this.listaAdyacencia.add(new ArrayList<>());
        }
    }
//constructor para definir e inicializar las variables
    public void agregarArista(char origen, char destino, int peso) {
        this.listaAdyacencia.get(origen - 'A').add(new Arista(destino - 'A', peso));//definir letras 
    }
    //metodo para crear el dijkstra
    public List<Character> dijkstra(char origen, char destino) {
        PriorityQueue<Nodo> colaPrioridad = new PriorityQueue<>(cantidadVertices, Comparator.comparingInt(a -> a.peso));
        int[] distancias = new int[cantidadVertices];
        int[] previos = new int[cantidadVertices];//arreglo para cantidad de vertices
        Arrays.fill(distancias, Integer.MAX_VALUE);
        Arrays.fill(previos, -1);
        colaPrioridad.add(new Nodo(origen - 'A', 0));
        distancias[origen - 'A'] = 0;//define origen
        while (!colaPrioridad.isEmpty()) {
            Nodo nodoActual = colaPrioridad.poll();
            int u = nodoActual.vertice;
//para ver cantidad de aritas e ingresar dartos
            for (Arista arista : listaAdyacencia.get(u)) {
                int v = arista.destino;
                int peso = arista.peso;
                if (distancias[u] + peso < distancias[v]) {
                    distancias[v] = distancias[u] + peso;
                    previos[v] = u;
                    colaPrioridad.add(new Nodo(v, distancias[v]));
                }
            }
        }
//lista de modo carcter busca la ruta y el destino
        List<Character> ruta = new ArrayList<>();
        for (int i = destino - 'A'; i != -1; i = previos[i]) {
            ruta.add((char) (i + 'A'));
        }
        Collections.reverse(ruta);
        return ruta;
    }
//metodo para vertice y peso
    private static class Nodo {
        private final int vertice;
        private final int peso;
//nodo para el vertice y el peso
        public Nodo(int vertice, int peso) {
            this.vertice = vertice;
            this.peso = peso;
        }
    }
//metodo para realizar la suma y saber el peso del grafo y la ruta
    public int sumaPesosAristas(List<Character> ruta) {
        int suma = 0;
        for (int i = 0; i < ruta.size() - 1; i++) {
            char origen = ruta.get(i);
            char destino = ruta.get(i + 1);
            int peso = obtenerPesoArista(origen, destino);
            suma += peso;
        }
        return suma;
    }
//metodo para mostrar la matriz de adyacencia
    public void mostrarMatrizAdyacencia() {
        System.out.println("Matriz de Adyacencia es ");
        for (int i = 0; i < cantidadVertices; i++) {
            for (int j = 0; j < cantidadVertices; j++) {
                int peso = obtenerPesoArista((char) ('A' + i), (char) ('A' + j));
                System.out.print((peso == Integer.MAX_VALUE ? "0" : peso) + " ");
            }
            System.out.println();
        }
    }
//metodo para obtener el peso de las aristas
    private int obtenerPesoArista(char origen, char destino) {
        for (Arista arista : listaAdyacencia.get(origen - 'A')) {
            if (arista.destino == destino - 'A') {
                return arista.peso;
            }
        }
        return Integer.MAX_VALUE;
    }
    public void mostrarAristas() {
        System.out.println("Lista de adyacencia:");
        for (int i = 0; i < cantidadVertices; i++) {
            for (Arista arista : listaAdyacencia.get(i)) {
                System.out.println((char) (i + 'A') + " -> " + arista.destino + " Peso: " + arista.peso);
            }}}
//metodo para inicializar las aristas
    private static class Arista {
        private final int destino;
        private final int peso;
//constructor del metodo arustas
        public Arista(int destino, int peso) {
            this.destino = destino;
            this.peso = peso;
        }
    }}