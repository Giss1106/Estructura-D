/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package grafobusqueda;
public class GrafoBusqueda {
    public static void main(String[] args) {
        // TODO code application logic here
       Grafo grafo = new Grafo(9); // Por ejemplo, un grafo con 6 vértices

        // Agregar aristas al grafo
        grafo.agregarArista('A', 'B', 10);
        grafo.agregarArista('A', 'C', 15);
        grafo.agregarArista('B', 'D', 12);
        grafo.agregarArista('B', 'F', 15);
        grafo.agregarArista('C', 'E', 10);
        grafo.agregarArista('C', 'G', 8);
        grafo.agregarArista('D', 'E', 5);
        grafo.agregarArista('D', 'H', 7);
        grafo.agregarArista('E', 'F', 7);
        grafo.agregarArista('E', 'I', 8);
        grafo.agregarArista('F', 'I', 6);
        grafo.agregarArista('G', 'H', 12);
        grafo.agregarArista('H', 'I', 10);

        System.out.println("LISTA" );

        grafo.mostrarAristas();
        
        System.out.println("EL RECORRIDO ES " + grafo.dijkstra('A', 'I'));
        System.out.println("EL PESO ES " + grafo.sumaPesosAristas(grafo.dijkstra('A', 'I')));
        grafo.mostrarMatrizAdyacencia();
    }
}