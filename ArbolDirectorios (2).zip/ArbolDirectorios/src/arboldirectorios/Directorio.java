/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package arboldirectorios;
import java.util.LinkedList;
import java.util.Queue;
// Clase que representa un directorio en el árbol de directorios
public class Directorio {
   String nombre; // Nombre del directorio
    LinkedList<Directorio> subdirectorios; // Lista de subdirectorios
    LinkedList<String> archivos; // Lista de archivos en el directorio
// Constructor para inicializar un directorio con un nombre dado
    public Directorio(String nombre) {
        this.nombre = nombre;
        this.subdirectorios = new LinkedList<>();
        this.archivos = new LinkedList<>();
    }
// Método para agregar un nuevo directorio al directorio actual
    public void agregarDirectorio(Directorio directorio) {
        //agregar un nuevo directorio al directorio actual.
        subdirectorios.add(directorio);//agrega el nuevo directorio a la lista de subdirectorios del directorio actual usando el método add 
    }
// Método para agregar un nuevo archivo al directorio actual
    public void agregarArchivo(String archivo) {
        archivos.add(archivo);
    }
// Método para eliminar un directorio del directorio actual por nombre
    public void eliminarDirectorio(String nombre) {
        //agregar un nuevo archivo al directorio actual.
        subdirectorios.removeIf(d -> d.nombre.equals(nombre));//agrega el nuevo archivo a la lista de archivos del directorio actual usando el método add 
    }
// Método para eliminar un archivo del directorio actual por nombre
    public void eliminarArchivo(String archivo) { 
//eliminar un directorio del directorio actual por nombre.
        archivos.remove(archivo);
    }
 // Método para mostrar la estructura del árbol de directorios
    public void mostrarDirectorio() { //recorrido por niveles
        Queue<Directorio> cola = new LinkedList<>();//Comienza en el directorio actual y agrega cada directorio a la cola.
        cola.offer(this);

        while (!cola.isEmpty()) {
            Directorio actual = cola.poll();
            System.out.println(actual.nombre + "/");
            for (String archivo : actual.archivos) {
                System.out.println("-- " + archivo);
                //retira un directorio de la cola, imprime su nombre y luego agrega todos sus subdirectorios a la cola
            }
            for (Directorio subdir : actual.subdirectorios) {
                cola.offer(subdir);
            }
        }
    }
// Método para buscar un archivo en el árbol de directorios
    public boolean buscarArchivo(String archivo) {
        Queue<Directorio> cola = new LinkedList<>(); //para recorrer todos los directorios y archivos en el árbol.
        cola.offer(this); //para realizar el recorrido por niveles.
        
        while (!cola.isEmpty()) { //Comienza en el directorio actual y agrega cada directorio a la cola.
            Directorio actual = cola.poll();
            if (actual.archivos.contains(archivo)) {
                System.out.println("El archivo \"" + archivo + "\" fue encontrado en el directorio \"" + actual.nombre + "\" ");
                return true;
            }//retira un directorio de la cola y verifica si la lista de archivos contiene el archivo buscado.
            for (Directorio subdir : actual.subdirectorios) {
                cola.offer(subdir);
            }
        }
//Si termina de recorrer el árbol sin encontrar el archivo, devuelve false.
        return false;
    }
}
