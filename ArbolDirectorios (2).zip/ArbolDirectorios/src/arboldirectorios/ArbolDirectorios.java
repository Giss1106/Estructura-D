/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arboldirectorios;

import java.util.Scanner;

public class ArbolDirectorios {
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scanner = new Scanner(System.in);
        Directorio raiz = new Directorio("Raiz"); // Crear el directorio raíz
        boolean salir = false;
        while (!salir) { //cuando se de la opcion 7 se saldra del programa directamente
            // Mostrar el menú de opciones al usuario
            System.out.println("Seleccione una opcion:");
            System.out.println("1. Agregar directorio");
            System.out.println("2. Agregar archivo a un directorio existente");
            System.out.println("3. Eliminar un directorio");
            System.out.println("4. Eliminar un archivo de un directorio existente");
            System.out.println("5. Mostrar estructura del arbol de directorios");
            System.out.println("6. Buscar un archivo");
            System.out.println("7. Salir del programa");
            int opcion = scanner.nextInt(); // Leer la opción seleccionada por el usuario
            scanner.nextLine();  // Consumir el salto de línea después del entero

            switch (opcion) {
                case 1: // Agregar un nuevo directorio
                    System.out.println("Ingrese nombre para el nuevo directorio:");
                    String nombreDirectorio = scanner.nextLine();
                    raiz.agregarDirectorio(new Directorio(nombreDirectorio));
                    break;
                case 2: // Agregar un archivo a un directorio existente
                    System.out.println("Ingrese el nombre del directorio existente:");
                    String nombreDir = scanner.nextLine(); //para ingresar el nuevo nombre
                    Directorio directorioExistente = null;
                    for (Directorio dir : raiz.subdirectorios) {
                        if (dir.nombre.equals(nombreDir)) { //busca el directorio
                            directorioExistente = dir;
                            break;
                        }
                    }
                    if (directorioExistente != null) {//en el directorio existente pide el ingreso del nombre del archivo
                        System.out.println("Ingrese el nombre del nuevo archivo:");
                        String nombreArchivo = scanner.nextLine(); //ingreso el nombre
                        directorioExistente.agregarArchivo(nombreArchivo);//Se agrega el archivo al directorio
                        System.out.println("Nuevo archivo agregado");
                    } else {
                        System.out.println("El directorio especificado no existe."); //si el directorio no existe muestra este mensaje
                    }
                    break;
                case 3: // Eliminar un directorio
                    System.out.println("Ingrese el nombre del directorio a eliminar:"); //pide el nombre del directorio para eliminar
                    String nombreEliminar = scanner.nextLine();
                    raiz.eliminarDirectorio(nombreEliminar);//buscar el directorio y lo elimina
                    System.out.println("Directorio eliminado");
                    break;
                case 4: // Eliminar un archivo de un directorio existente
                    System.out.println("Ingrese el nombre del directorio donde se encuentra el archivo:");
                    String nombreDirEliminar = scanner.nextLine(); // ingresa el nombre del direectorio
                    Directorio dirEliminar = null;
                    for (Directorio dir : raiz.subdirectorios) { //busca el directorio
                        if (dir.nombre.equals(nombreDirEliminar)) {
                            dirEliminar = dir;
                            break;
                        }
                    }
                    if (dirEliminar != null) { //recorrido para eliminar el archivo
                        System.out.println("Ingrese el nombre del archivo a eliminar:");
                        String archivoEliminar = scanner.nextLine(); //ingrso del nombre del archivo a elimianr
                        dirEliminar.eliminarArchivo(archivoEliminar);//elimina el archivo
                        System.out.println("Archivo eliminado");
                    } else {
                        System.out.println("El directorio especificado no existe.");// si no existe el directorio mustra este mensaje
                    }
                    break;
                case 5: // Mostrar la estructura del árbol de directorios
                    System.out.println("Estructura del arbol de directorios:");
                    raiz.mostrarDirectorio();//muestra la extructura del arbol crea con todos los datos actualizados
                    break;
                case 6: // Buscar un archivo en el árbol de directorios
                    System.out.println("Ingrese el nombre del archivo a buscar:");
                    String nombreArchivoBuscar = scanner.nextLine(); //busca el nombre del archivo
                    if (raiz.buscarArchivo(nombreArchivoBuscar)) {
                        
                        System.out.println("El archivo \"" + nombreArchivoBuscar + "\" fue encontrado.");
                        
                    } else {
                        System.out.println("El archivo \"" + nombreArchivoBuscar + "\" no fue encontrado.");
                    }
                    break;
                case 7: // Salir del programa
                    salir = true;
                    break;
                default: // Opción no válida
                    System.out.println("Opcion no valida. Por favor, ingrese un numero valido.");
            }
        }
        scanner.close(); // Cerrar el scanner al salir del programa
    }
}
