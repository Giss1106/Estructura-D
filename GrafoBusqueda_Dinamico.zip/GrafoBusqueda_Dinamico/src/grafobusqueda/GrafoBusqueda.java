/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package grafobusqueda;

import java.util.List;
import java.util.Scanner;

public class GrafoBusqueda {
    public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el numero de vertices del grafo: ");
        int numVertices = scanner.nextInt();
        Grafo grafo = new Grafo(numVertices);

        System.out.println("Ingrese las aristas del grafo.");
        System.out.println("Para cada arista, ingrese el origen, destino y peso.");
        System.out.println("Escriba 'fin' para terminar la entrada.");

        while (true) {
            System.out.print("Origen: ");
            String entrada = scanner.next();
            if (entrada.equals("fin")) break;
            int origen = Integer.parseInt(entrada);
            
            System.out.print("Destino: ");
            int destino = scanner.nextInt();
            
            System.out.print("Peso: ");
            int peso = scanner.nextInt();
            
            grafo.agregarArista(origen, destino, peso);
        }

        System.out.print("Ingrese el vertice de origen: ");
        int origen = scanner.nextInt();
        System.out.print("Ingrese el vertice de destino: ");
        int destino = scanner.nextInt();

        List<Integer> ruta = grafo.dijkstra(origen, destino);
        System.out.println("El recorrido es: " + ruta);
        System.out.println("El peso es: " + grafo.sumaPesosAristas(ruta));
        grafo.mostrarMatrizAdyacencia();
    }
}