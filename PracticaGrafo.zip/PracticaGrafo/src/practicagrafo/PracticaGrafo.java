/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practicagrafo;

import practicagrafo.NodoGrafo;
import practicagrafo.Grafo;
import practicagrafo.EstadoNodoGrafo;
import practicagrafo.BusquedaEnProfundidad;
import practicagrafo.BusquedaEnAmplitud;

/**
 *
 * @author ESPE
 */
public class PracticaGrafo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Crear un grafo
        Grafo grafo = new Grafo();

        // Agregar nodos y aristas
        grafo.agregarArista("A", "B");
        grafo.agregarArista("B", "C");
        grafo.agregarArista("C", "D");
        grafo.agregarArista("D", "E");

        // Realizar búsqueda en profundidad
        String objetivoProfundidad = "E";
        boolean encontradoProfundidad = BusquedaEnProfundidad.BusquedaEnProfundidad(grafo, objetivoProfundidad);

        if (encontradoProfundidad) {
            System.out.println("El nodo " + objetivoProfundidad + " fue encontrado utilizando busqueda en profundidad.");
        } else {
            System.out.println("El nodo " + objetivoProfundidad + " no fue encontrado utilizando busqueda en profundidad.");
        }

        // Reiniciar los estados de los nodos para la búsqueda en amplitud
        reiniciarEstados(grafo);

        // Realizar búsqueda en amplitud
        String objetivoAmplitud = "E";
        boolean encontradoAmplitud = BusquedaEnAmplitud.BusquedaEnAmplitud(grafo, objetivoAmplitud);

        if (encontradoAmplitud) {
            System.out.println("El nodo " + objetivoAmplitud + " fue encontrado utilizando busqueda en amplitud.");
        } else {
            System.out.println("El nodo " + objetivoAmplitud + " no fue encontrado utilizando busqueda en amplitud.");
        }
    }

    // Método para reiniciar los estados de los nodos en el grafo
    private static void reiniciarEstados(Grafo grafo) {
        for (NodoGrafo nodo : grafo.nodos.values()) {
            nodo.estado = EstadoNodoGrafo.NoVisitado;
        }
    }
}